#!/bin/bash
# Senhor Multi-Folder File Download Script

# Copyright (c) 2025 turri21 <turri21@yahoo.com>

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

###############################################
# ASCII Art Logo
###############################################
echo -e "\e[1;36m"
cat << "EOF"

                                           -*%@%%#####+-.                                           
                                         :@@@@%%%%%@@@@@@#.                                         
                                        -@@@-..::::::::*@@@:                                        
                           =*+.         @@@***:.:**=:=***@@#         :*#-                           
                         =@@@@@#.      =@@#:=-...-=::-==:@@@:      :#@@@@%:                         
                        *@@@%@@@@+     @@@#+===----===+++%@@+     +@@@@@@@@-                        
                      .%@@@+ .*@@@%:  .@@@--=+++****++++=+@@@   .%@@@*..%@@@=                       
                      @@@@- -= :@@@@= +@@%*++===-====++***@@@: -@@@@- +: %@@@=                      
                     @@@@- *@@@. #@@@#%@@-...::::-=---::::*@@**@@@%.-@@@@@@@@@@@@@@%+-              
                    %@@@- *@%=@@- +@@@@@%........:::::::::-@@@@@@@@@@@@@@@@%#*###@@@@@@*            
                  :#@@@= =@@==+@@+ -@@@@###***++*****##*#%%@@@@@@@#+===+-=:::=-=:::-+*@@%           
               .=%@@@@%:.@@@%%%@@@- -@@@----======+***###+-=*#*=-==+=+##*#######*++-=.%@@-          
              =@@@@@@@@@@@%#++++=++*%@@@##***##%%%#=:--::.-+-+*#%%*=-.:::::::::::=#%-:@@@:          
             %@@@-:.: =#%@@@@@@@@@@@@@%:.:....:==...-=:*%@@#+-..::..:::::::::::::::+%#@@+           
            +@@@%#*+++*%%##+*:--=::===..===:.:=--+##%*-:::.::::::.-..::::::::.-::::=@@@#            
            @@@@-.::.:..:---==+**##%#%##%####***+=-::....::::..:=+******+=-:::::::=%@@@#            
            @@@@@+:..........:.................::::::.::.:-+**#*+-:..::::-+%+::-+%@@@@@@            
            @@@@@@@#=:: ............:::::..: ::...---+*###=-        ...   .:#%@@@@#-%@@@            
            @@@* *@@@@@@+::.........::.::::.:-+*#%%*-        ..:+%@@@@@@*@@@@@@%-   %@@@            
            @@@#    :*@@@@@@@%+=-:.:-+%@@#*+=:             .%@@@@@@@@@@@@@@*=       %@@@            
            @@@#       .:-*%@@@@@@@@@@@%%%%%%%%@%%@@@@@@@@@@@@@@@@@#*+-:..          %@@@            
            @@@%.            .::-==+**###%%@@@@%####%@@@%==--::.                  .=@@@@            
            @@@@@+-------------------------@@@@%=---%@@@#------------------------+@@@@@@            
            @@@@@@@@@%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#%@@@            
            @@@* #@@=-#-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*:*:@@@@@@@@@@@@@@@@@@@@@@@+ %@@@            
           =@@@* +@@%++@@@@@@@@@@@@@@@@@@@@@@@@@*=-#@@@%%-@@@@@@@@@@@@@@@@@@@@@@@@= %@@@=           
        .*@@@@@* :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=+++@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  *@@@@@+         
       +@@@@*-.   *@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-    -*@@@@=       
      #@@@#.       *@@@@@@@@@@@@@@@@@@@@@@@@@@@#++++#@@@@@@@@@@@@@@@@@@@@@@@@@@@=       :%@@@+      
     *@@@+          =@@@@@@@@@@@@@@@@@@@@@%=-@@@@=+@@@@=:*@@@@@@@@@@@@@@@@@@@@@:          #@@@=     
    .@@@#             +@@@@@@@@@@@@@@@@@%::---:*@@@@+:----:*@@@@@@@@@@@@@@@@@-             %@@@     
    =@@@=              .:*@@@@@@@@@@@@@@#*----------------+#@@@@@@@@@@@@@%+:.              =@@@=    
    *@@@:                  :-==+**++@@@#-*%-----+%%=:---:#*=*@%@#+**+==-:                  :@@@+    
    =@@@=                  .......-@=.%@@%==++#@@@@@%*++==%@@%.:%+........                 =@@@=    
    .@@@%.                  ......@-..%*#%%@@@#=----*@@@@%%*=@:..@-.....                   %@@@     
     =@@@%                    .. +#  #*.....#@@@@@@@@@@#.....-@..=@ ..                    %@@@=     
      =@@@@+                     == :@........::::::::....... %+.-#                     +@@@@=      
       :%@@@@*=.                    =@ ...................... +#                    .-*@@@@%:       
         -#@@@@*                    .:     ..............     ..                    @@@@@#=         
           .@@@*                                                                    @@@@            
            @@@*                                                                    @@@@            
            @@@*                                                                    @@@@            
           -@@@*                                                                    @@@@-           
        .*@@@@@*                                                                    %@@@@%+         
       .@@@@#=-:                                                                     :=#@@@%.       
       %@@@-                                .-*%@@@@%+:.                                -@@@%       
      .@@@*                               :@@@@@@@@@@@@@%.                               +@@@-      
       @@@%                              #@@@@*:....-*@@@@*                              +@@@-      
       *@@@+                           .%@@@+.        .+@@@#                            -@@@%       
        #@@@%+=========================#@@@=            +@@@*=========================+%@@@%:       
         =%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+         
           .+%%%%%%%%%%%%%%%%%%%%%%%%%%%%%=              +%%%%%%%%%%%%%%%%%%%%%%%%%%%%#=.           
EOF
echo -e "\e[0m"
echo "==============================================="
echo " Automated RBF Downloader for Senhor FPGA"
echo "==============================================="
echo 

###############################################
# Configuration
###############################################
REPO_OWNER="turri21"
REPO_NAME="Distribution_Senhor"
BASE_URL="https://raw.githubusercontent.com/$REPO_OWNER/$REPO_NAME/main"

declare -A FOLDERS=(
    ["_Arcade"]="/media/fat/_Arcade"
    ["_Arcade/_ST-V"]="/media/fat/_Arcade/_ST-V"
    ["_Arcade/_ST-V/_JP Bios"]="/media/fat/_Arcade/_ST-V/_JP Bios"
    ["_Arcade/_jotego"]="/media/fat/_Arcade/_jotego"
    ["_Arcade/cores"]="/media/fat/_Arcade/cores"
    ["_Computer"]="/media/fat/_Computer"
    ["_Console"]="/media/fat/_Console"
    ["_Other"]="/media/fat/_Other"
    ["_Other/cores"]="/media/fat/_Other/cores"
    ["_Utility"]="/media/fat/_Utility"    
)

FILE_LIST_EXT="file_list.txt"
TEMP_DIR="/tmp/senhor_download"
LOG_FILE="/media/fat/scripts/senhor_download.log"
DELETE_OLD_FILES=false

mkdir -p "$TEMP_DIR"

for folder in "${!FOLDERS[@]}"; do
    mkdir -p "${FOLDERS[$folder]}"
done
touch "$LOG_FILE"

###############################################
# Functions
###############################################

log() {
    local msg="$(date "+%Y-%m-%d %H:%M:%S") - $1"
    echo "$msg" >> "$LOG_FILE"
    echo "$msg" > /dev/tty1
    echo -e "\e[1;34m$msg\e[0m"
}

check_internet() {
    log "Checking internet connection..."
    if ! ping -4 -q -c 1 -W 3 1.1.1.1 >/dev/null; then
        log "ERROR: No internet connection. Please check your network and try again."
        echo -e "\e[1;31mNo internet connection. Exiting.\e[0m"
        read -p "Press enter to exit..."
        exit 1
    fi
    log "Internet connection is available."
}

prompt_delete_mode() {
    echo -e "\e[1;33mDo you want to delete older versions of RBF/MGL/MRA files?\e[0m"
    read -rp "Enable deletion of old RBF/MGL/MRA versions? [y/N]: " response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        DELETE_OLD_FILES=true
        log "Old version deletion enabled."
    else
        log "Old version deletion disabled."
    fi
}

fetch_file_list() {
    local folder="$1"
    local list_file="$TEMP_DIR/${folder}_$FILE_LIST_EXT"
    local file_list_url="$BASE_URL/$folder/$FILE_LIST_EXT"

    log "Fetching file list for $folder..."

    mkdir -p "$(dirname "$list_file")"

    if ! wget -q --tries=3 --timeout=15 "$file_list_url" -O "$list_file"; then
        log "\e[31mWARNING: No file list found for $folder\e[0m"
        FILES=()
        return 1
    fi

    FILES=()
    while IFS= read -r line; do
        line="${line%%#*}"
        line="${line##*/}"
        line="${line//[$'\t\r\n']}"
        [[ "$line" =~ \.(rbf|mgl|mra)$ ]] && FILES+=("$line")
    done < "$list_file"

    local count=${#FILES[@]}
    if [ "$count" -eq 0 ]; then
        log "WARNING: No valid files found in $folder list"
        return 1
    fi

    log "Found $count supported files in $folder"
    return 0
}

delete_old_versions() {
    local folder="$1"
    local new_file="$2"
    local download_dir="${FOLDERS[$folder]}"
    local full_path_new="$download_dir/$new_file"

    # Extract base (everything up to the 2nd underscore) and version (after 2nd underscore)
    local base_prefix=$(echo "$new_file" | cut -d'_' -f1-2)
    local new_version=$(echo "$new_file" | cut -d'_' -f3 | cut -d'.' -f1)
    local ext="${new_file##*.}"

    for existing in "$download_dir"/"$base_prefix"_*."$ext"; do
        [[ ! -f "$existing" || "$existing" == "$full_path_new" ]] && continue

        local existing_file=$(basename "$existing")
        local existing_version=$(echo "$existing_file" | cut -d'_' -f3 | cut -d'.' -f1)

        if [[ "$existing_version" < "$new_version" ]]; then
            log "\e[31mDeleting older version: \e[0m\e[1;33m$existing_file\e[0m"
            rm -f "$existing"
        fi
    done
}

download_arcadealt() {
    ZIP_URL="https://github.com/turri21/Distribution_Senhor/raw/main/_Arcade/_alternatives.zip"
    DEST_DIR="/media/fat/_Arcade"
    TEMP_ZIP="/tmp/_alternatives.zip"

    echo "Deleting old _alternatives folder..."
    rm -rf "/media/fat/_Arcade/_alternatives"
    echo "Downloading Arcade mra _alternatives.zip with wget..."
    wget -O "$TEMP_ZIP" "$ZIP_URL"

    if [ $? -ne 0 ]; then
        echo "Download failed."
        exit 1
    fi

    echo "Extracting ZIP to $DEST_DIR..."
    unzip -o "$TEMP_ZIP" -d "$DEST_DIR"

    if [ $? -ne 0 ]; then
        echo "Extraction failed."
        exit 1
    fi

    echo "Cleaning up..."
    rm "$TEMP_ZIP"

    echo "Done."
}

download_file() {
    local folder="$1"
    local file="$2"
    local download_dir="${FOLDERS[$folder]}"
    local max_retries=3
    local retry_delay=2

    if [ -s "$download_dir/$file" ]; then
        log "Skipping existing file: $folder/$file"
        return 0
    fi

    for ((i=1; i<=max_retries; i++)); do
        log "Download attempt $i for $folder/$file..."
        if wget -q --tries=3 --timeout=15 "$BASE_URL/$folder/$file" -O "$TEMP_DIR/$file"; then
            if [ -s "$TEMP_DIR/$file" ]; then
                if $DELETE_OLD_FILES; then
                    delete_old_versions "$folder" "$file"
                fi
                mv "$TEMP_DIR/$file" "$download_dir/"
                log "Successfully downloaded: \e[1;32m$folder/$file\e[0m"
                return 0
            else
                log "Attempt $i: Downloaded empty file"
                rm -f "$TEMP_DIR/$file"
            fi
        fi
        sleep $retry_delay
    done

    log "ERROR: Failed to download after $max_retries attempts: \e[1;31m$folder/$file\e[0m"
    return 1
}

###############################################
# Arcade ROMs
###############################################
download_arcaderoms() {
    # Base target directory
    BASE_DIR="/media/fat"

    echo "Downloading..."
    wget -O "$BASE_DIR/arcade_roms_db.json.zip" "https://raw.githubusercontent.com/zakk4223/ArcadeROMsDB_MiSTer/db/arcade_roms_db.json.zip"

    if [ $? -ne 0 ]; then
        echo "Download failed."
        return 1
    fi

    echo "Extracting JSON file..."
    unzip -o "$BASE_DIR/arcade_roms_db.json.zip" -d "$BASE_DIR"

    echo "Processing JSON..."

    # Check if jq is installed
    if ! command -v jq &> /dev/null; then
        echo "This script requires 'jq'. Please install it (e.g., 'sudo apt install jq')."
        return 1
    fi

    jq -r '.files | to_entries[] | "\(.key) \(.value.url)"' "$BASE_DIR/arcade_roms_db.json" | while read -r path url; do
        # Remove leading pipe character
        relative_path="${path#|}"

        # Compute full output path
        full_path="$BASE_DIR/$relative_path"

        # Create directory if needed
        mkdir -p "$(dirname "$full_path")"

        # Download file if it doesn't exist
        if [ ! -f "$full_path" ]; then
            echo "Downloading $relative_path..."
            wget -q -O "$full_path" "$url"
        else
            echo "File $relative_path already exists. Skipping."
        fi
    done

    echo "All files processed and saved under $BASE_DIR."
}

###############################################
# BIOS files
###############################################

download_bios() {
    # Base target directory
    BASE_DIR="/media/fat"

    echo "Downloading..."
    wget -O "$BASE_DIR/bios_db.json.zip" "https://raw.githubusercontent.com/ajgowans/BiosDB_MiSTer/db/bios_db.json.zip"

    if [ $? -ne 0 ]; then
        echo "Download failed."
        return 1
    fi

    echo "Extracting JSON file..."
    unzip -o "$BASE_DIR/bios_db.json.zip" -d "$BASE_DIR"

    echo "Processing JSON..."

    # Check if jq is installed
    if ! command -v jq &> /dev/null; then
        echo "This script requires 'jq'. Please install it (e.g., 'sudo apt install jq')."
        return 1
    fi

    jq -r '.files | to_entries[] | "\(.key) \(.value.url)"' "$BASE_DIR/bios_db.json" | while read -r path url; do
        # Remove leading pipe character
        relative_path="${path#|}"

        # Compute full output path
        full_path="$BASE_DIR/$relative_path"

        # Create directory if needed
        mkdir -p "$(dirname "$full_path")"

        # Download file if it doesn't exist
        if [ ! -f "$full_path" ]; then
            echo "Downloading $relative_path..."
            wget -q -O "$full_path" "$url"
        else
            echo "File $relative_path already exists. Skipping."
        fi
    done

    echo "All files processed and saved under $BASE_DIR."
}

###############################################
# Generic Download and Extract Function
###############################################

download_and_extract() {
    local ZIP_NAME="$1"
    local ZIP_URL_FULL="$2"
    local ZIP_DIR="/tmp/${ZIP_NAME}_download"
    local OUTPUT_DIR="/media/fat"

    mkdir -p "${ZIP_DIR}"
    cd "${ZIP_DIR}"

    local ZIP_BASE="${ZIP_NAME}.zip"
    local ZIP_Z01="${ZIP_NAME}.z01"
    local ZIP_URL_BASE=$(dirname "${ZIP_URL_FULL}")

    echo "Checking for split archive: ${ZIP_Z01}..."

    if wget --spider --quiet "${ZIP_URL_BASE}/${ZIP_Z01}"; then
        echo "Split archive found. Downloading parts..."
        wget --show-progress -q "${ZIP_URL_BASE}/${ZIP_Z01}" -O "${ZIP_Z01}"
        wget --show-progress -q "${ZIP_URL_BASE}/${ZIP_BASE}" -O "${ZIP_BASE}"

        echo "Joining parts: ${ZIP_Z01} + ${ZIP_BASE}..."
        zip -s 0 "${ZIP_BASE}" --out "joined_${ZIP_BASE}"

        echo "Extracting to ${OUTPUT_DIR}..."
        unzip -o "joined_${ZIP_BASE}" -d "${OUTPUT_DIR}"
    else
        echo "No split archive found. Downloading ${ZIP_BASE}..."
        wget --show-progress -q "${ZIP_URL_BASE}/${ZIP_BASE}" -O "${ZIP_BASE}" || {
            echo "Failed to download ${ZIP_BASE}"
            return 1
        }

        echo "Extracting to ${OUTPUT_DIR}..."
        unzip -o "${ZIP_BASE}" -d "${OUTPUT_DIR}"
    fi

    echo "Cleaning up..."
    rm -rf "$ZIP_DIR"

    echo "${ZIP_NAME} done."
}


###############################################
# Specific Download Wrappers
###############################################

download_menu() {
    download_and_extract "Menu" "https://github.com/turri21/Distribution_Senhor/raw/main/menu.zip"
}

download_cheats() {
    download_and_extract "Cheats" "https://github.com/turri21/Distribution_Senhor/raw/main/Cheats.zip"
}

download_filters() {
    download_and_extract "Filters" "https://github.com/turri21/Distribution_Senhor/raw/main/Filters.zip"
}

download_filtersaudio() {
    download_and_extract "Filters_Audio" "https://github.com/turri21/Distribution_Senhor/raw/main/Filters_Audio.zip"
}

download_font() {
    download_and_extract "font" "https://github.com/turri21/Distribution_Senhor/raw/main/font.zip"
}

download_gamma() {
    download_and_extract "Gamma" "https://github.com/turri21/Distribution_Senhor/raw/main/Gamma.zip"
}

download_presets() {
    download_and_extract "Presets" "https://github.com/turri21/Distribution_Senhor/raw/main/Presets.zip"
}

download_scripts() {
    download_and_extract "Scripts" "https://github.com/turri21/Distribution_Senhor/raw/main/Scripts.zip"
}

download_shadowmasks() {
    download_and_extract "Shadow_Masks" "https://github.com/turri21/Distribution_Senhor/raw/main/Shadow_Masks.zip"
}

###############################################
# Main Process
###############################################

main() {
    check_internet
    prompt_delete_mode

    # Menu using whiptail
    CHOICES=$(whiptail --title "Senhor Downloader" --checklist \
        "Choose what you want to download (use space to select):" 20 60 10 \
        "RBF" "Download RBF/MGL/MRA files" ON \
        "Menu" "Download Menu" ON \
        "Alternatives" "Download Alternative MRA files" OFF \
        "ArcadeROMs" "Download Arcade ROMs [SLOW]" OFF \
        "BIOS" "Download BIOS files [SLOW]" OFF \
        "Cheats" "Download Cheats" OFF \
        "Filters" "Download Filters" OFF \
        "Filters_Audio" "Download Filters_Audio" OFF \
        "Fonts" "Download Fonts" OFF \
        "Gamma" "Download Gamma" OFF \
        "Presets" "Download Presets" OFF \
        "Scripts" "Download Scripts" OFF \
        "Shadow_Masks" "Download Shadow Masks" OFF \
        3>&1 1>&2 2>&3)

    # User cancelled
    if [ $? -ne 0 ]; then
        echo "User cancelled. Exiting."
        exit 1
    fi

    # Flags
    run_rbf=false
    run_menu=false
    run_alternatives=false
    run_roms=false
    run_bios=false
    run_cheats=false
    run_filters=false
    run_filtersaudio=false
    run_font=false
    run_gamma=false
    run_presets=false
    run_scripts=false
    run_shadowmasks=false

    for choice in $CHOICES; do
        case $choice in
            "\"RBF\"")
                run_rbf=true
                ;;
            "\"Menu\"")
                run_menu=true
                ;;
            "\"Alternatives\"")
                run_alternatives=true
                ;;
            "\"ArcadeROMs\"")
                run_roms=true
                ;;
            "\"BIOS\"")
                run_bios=true
                ;;
            "\"Cheats\"")
                run_cheats=true
                ;;
            "\"Filters\"")
                run_filters=true
                ;;
             "\"Filters_Audio\"")
                run_filtersaudio=true
                ;;
            "\"Fonts\"")
                run_font=true
                ;;
            "\"Gamma\"")
                run_gamma=true
                ;;
            "\"Presets\"")
                run_presets=true
                ;;
            "\"Scripts\"")
                run_scripts=true
                ;;
            "\"Shadow_Masks\"")
                run_shadowmasks=true
                ;;
        esac
    done

    # Execute choices
    if $run_rbf; then
        log "=== Starting RBF/MGL/MRA download ==="
        local total_success=0
        local total_files=0

        for folder in "${!FOLDERS[@]}"; do
            log "Processing folder: \e[1;35m$folder\e[0m"

            if fetch_file_list "$folder"; then
                ((total_files += ${#FILES[@]}))
            else
                continue
            fi

            for file in "${FILES[@]}"; do
                [[ -z "$file" ]] && continue
                if download_file "$folder" "$file"; then
                    ((total_success++))
                fi
            done
        done

        log "RBF/MGL/MRA complete: \e[1;32m$total_success\e[0m of \e[1;33m$total_files\e[0m files"
    fi
    
    if $run_menu; then
        download_menu
    fi

    if $run_alternatives; then
        download_arcadealt
    fi

    if $run_roms; then
        download_arcaderoms
    fi

    if $run_bios; then
        download_bios
    fi

    if $run_cheats; then
        download_cheats
    fi

    if $run_filters; then
        download_filters
    fi

    if $run_filtersaudio; then
        download_filtersaudio
    fi

    if $run_font; then
        download_font
    fi

    if $run_gamma; then
        download_gamma
    fi

    if $run_presets; then
        download_presets
    fi

    if $run_scripts; then
        download_scripts
    fi

    if $run_shadowmasks; then
        download_shadowmasks
    fi

    rm -rf "$TEMP_DIR"
    echo -e "\e[1;35m=================================================================\e[0m"
    echo "Finished selected operations."
    echo -e "\e[1;35m=================================================================\e[0m"
    read -p "Press enter to continue..."
}

main
exit 0
